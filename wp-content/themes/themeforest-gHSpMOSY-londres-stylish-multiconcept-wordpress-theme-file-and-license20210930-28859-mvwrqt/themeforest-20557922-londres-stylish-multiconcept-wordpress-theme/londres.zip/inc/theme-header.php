<?php
	
	$typeofheader = get_option("londres_header_style_type");
	
	get_template_part( 'inc/headers/header', $typeofheader );
	

?>